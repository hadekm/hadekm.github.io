
import cvxpy as cp
import numpy as np


x = cp.Variable()
y = cp.Variable()         

constraints = [
    2*x + y >= 2,
    x + 2*y >= 2]

obj = cp.Minimize( x + y )

prob = cp.Problem(obj, constraints)

prob.solve() 

print("status:", prob.status)
print("optimal value", prob.value)
print("optimal var", x.value, y.value)
