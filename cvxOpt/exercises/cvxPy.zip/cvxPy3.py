
import cvxpy as cp
import numpy as np


x = cp.Variable(3)


A = np.array(
    [[35, 0.5, 0.5],
    [60, 300, 10],
    [30,20,10]])
  
b = np.array([0.5, 15, 4])

c = np.array([0.75, 0.5, 0.15])

constraints = [
    A @ x >= b,
    x >= 0]

obj = cp.Minimize( c.T @ x )

prob = cp.Problem(obj, constraints)

prob.solve() 

print("status:", prob.status)
print("optimal value", prob.value)
print("optimal var", x.value)
