
import cvxpy as cp
import numpy as np


x = cp.Variable()
y = cp.Variable()
z = cp.Variable()
            

constraints = [
    x**2 + 2*(y**2) + z**2 <= 4]

obj = cp.Minimize( 4*x + 5*y + 3*z )

prob = cp.Problem(obj, constraints)

prob.solve() 

print("status:", prob.status)
print("optimal value", prob.value)
print("optimal var", x.value, y.value)
