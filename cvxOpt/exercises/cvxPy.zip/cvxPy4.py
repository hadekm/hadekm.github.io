
import cvxpy as cp
import numpy as np

#infeasible
x = cp.Variable()
y = cp.Variable()         

constraints = [
    2*x + y >= 2,
    x + 2*y >= 2,
    x + y <= 0]
    
obj = cp.Minimize( x + y )

prob = cp.Problem(obj, constraints)

prob.solve() 

print("Infeasible:")
print("status:", prob.status)
print("optimal value", prob.value)
print("optimal var", x.value, y.value)


#not unique
constraints = [
    2*x + y >= 2,
    x + 2*y >= 2,
    x + y >= 2]
    
obj = cp.Minimize( x + y )

prob = cp.Problem(obj, constraints)

prob.solve() 

print("Not unique:")
print("status:", prob.status)
print("optimal value", prob.value)
print("optimal var", x.value, y.value)


#unbounded      

constraints = [
    2*x + y >= 2,
    x + 2*y >= 2]
    
obj = cp.Maximize( x + y )

prob = cp.Problem(obj, constraints)

prob.solve() 

print("Unbounded:")
print("status:", prob.status)
print("optimal value", prob.value)
print("optimal var", x.value, y.value)


